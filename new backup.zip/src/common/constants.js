const SERVER_BASE_URL = "https://kk-time-table-server.herokuapp.com";
// const SERVER_BASE_URL = "https://api-service-finder.herokuapp.com/";
const CLIENT_BASE_URL = "http://localhost:3000/";

export { SERVER_BASE_URL, CLIENT_BASE_URL };
