import "./App.css";
import RoutesPage from "./RoutesPage";

function App() {
  return <RoutesPage />;
}

export default App;
