const Footer = () => {
  return (
    <div className="container-fluid p-0 border-top py-4">
      <p className="text-center mb-0">Copyright 2022 | All Rights Reserved</p>
    </div>
  );
};

export default Footer;
